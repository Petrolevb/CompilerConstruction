// 2 instead of 1 arguments

int main() {
	int x = foo(1,2);
	return 0 ;
}

int foo(int y) {
 return y;
}

