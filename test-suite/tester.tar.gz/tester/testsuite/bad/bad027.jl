// Assigning int to double variable.

int main () {
 double x;
 x = 1;
 return 0 ;
}