int f(int x, int x) {
   return x;
}